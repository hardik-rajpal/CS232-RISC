Assumed op code for LHI = 0011
Added extra op code for program termination: OC_TER = 0100

Note: We have provided a testbench generated using Quartus which can be configured to test the processor. 